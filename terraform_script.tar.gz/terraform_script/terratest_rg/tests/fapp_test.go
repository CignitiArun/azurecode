package test

import (
	"fmt"
	"log"
	"testing"

	"github.com/gruntwork-io/terratest/modules/azure"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
)

func TestTerraformAzureResourceGroupExample(t *testing.T) {
	t.Parallel()

	// subscriptionID is overridden by the environment variable "ARM_SUBSCRIPTION_ID"
	subscriptionID := "93f31a29-06cd-4975-b12d-d12f267e420c"

	// Configure Terraform setting up a path to Terraform code.
	terraformOptions := &terraform.Options{
		// The path to where our Terraform code is located
		TerraformDir: "../",
		Vars:         map[string]interface{}{},
	}

	// At the end of the test, run `terraform destroy` to clean up any resources that were created
	defer terraform.Destroy(t, terraformOptions)

	// Run `terraform init` and `terraform apply`. Fail the test if there are any errors.
	terraform.InitAndApply(t, terraformOptions)

	// Run `terraform output` to get the values of output variables
	resourceGroupName := terraform.Output(t, terraformOptions, "resource_group_name")
	fmt.Printf("ResourceGroupName :: %s\n", resourceGroupName)
	log.Printf(" Resource group output: %s\n", resourceGroupName)
	exists := azure.ResourceGroupExists(t, resourceGroupName, subscriptionID)
	assert.True(t, exists, "Resource group does not exist")

	appServiceName := terraform.Output(t, terraformOptions, "appName")
	exists = azure.AppExists(t, appServiceName, resourceGroupName, subscriptionID)
	assert.True(t, exists, "App does not exist")
	
	VirtualNetworkName := terraform.Output(t, terraformOptions, "virtual_network_name")
	exists = azure.VirtualNetworkExists(t, VirtualNetworkName, resourceGroupName, subscriptionID)
	assert.True(t, exists, "VirtualNetwork does not exist")
	
	SubnetName := terraform.Output(t, terraformOptions, "subnet_name")
	exists = azure.SubnetExists(t, SubnetName, VirtualNetworkName, resourceGroupName, subscriptionID)
	assert.True(t, exists, "SubnetName does not exist")
	
	functionAppName := terraform.Output(t, terraformOptions, "function_app_name")
	assert.True(t, azure.AppExists(t, functionAppName, resourceGroupName, subscriptionID))

	appId := terraform.Output(t, terraformOptions, "function_app_id")

	site := azure.GetAppService(t, functionAppName, resourceGroupName, subscriptionID)
	assert.NotEmpty(t, *site.OutboundIPAddresses)
	assert.Equal(t, appId, *site.ID)
}


