control 'resources' do
  resource_group_name = 'POC_Innovation'
  describe azurerm_virtual_network(resource_group: resource_group_name, name: 'example-network') do
    it               { should exist }
    its('location')  { should eq 'eastus' }
  end
  describe azure_subnet(resource_group: resource_group_name, vnet: 'example-network', name: 'service') do
    its('address_prefix') { should eq '10.0.1.0/24' }
  end
  describe azurerm_virtual_network(resource_group: resource_group_name, name: 'example-network') do
    it               { should exist }
    its('location')  { should eq 'eastus' }
  end
  describe azure_subnet(resource_group: resource_group_name, vnet: 'example-network', name: 'service') do
    its('address_prefix') { should eq '10.0.1.0/24' }
  end
  describe azure_storage_account(resource_group: resource_group_name, name: 'privatecfm')  do
    it { should exist }
  end
 
end
